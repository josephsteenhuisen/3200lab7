package com.example.k2023_04_23_boundservicetextview.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Binder
import android.os.IBinder
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import java.util.*

class TextViewService  : Service() {
    private val binder = LocalBinder()
    private var myText: String = "Start"
    //private val mediaPlayer: MediaPlayer? = null
    private val videoStream = "https://freetestdata.com/wp-content/uploads/2022/02/Free_Test_Data_2MB_MP4.mp4"
    private lateinit var myMediaController: MediaController
    private val mGenerator = Random()
    //private var mediaPlayer: MediaPlayer? = null
    private var mediaPlayer: MediaPlayer? = null

// Set the volume to a lower value (0.0 is silent, 1.0 is full volume)


    fun setupMediaPlayer(videoView: VideoView){
        videoView.setVideoURI(Uri.parse(videoStream))
        myMediaController = MediaController(this)
        myMediaController.setAnchorView(videoView)
        myMediaController.setMediaPlayer(videoView)

    }

    val randomNumber: Int
        get() = mGenerator.nextInt(100)

    fun updateText(newText: String) {
        myText = newText
    }
    fun muteAudio() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
    }
    fun setView(myView: TextView, videoView: VideoView) {
        myView.text = myText

        videoView.start()
    }

    inner class LocalBinder : Binder() {
        fun getService(): TextViewService = this@TextViewService
    }

    override fun onBind(intent: Intent): IBinder {
        return binder
    }
}